import celtstats.parser as pa

# Build a list from the original list and removes stop words.
# Stop words are defined in module parser
def remove_stop_words(data):
    list = []

    for a in data:
        if a not in pa.stop_words:
            list.append(a)

    return list


# Using a list, builds a dictionary where the key is the name of the document, and the value
# is another dictionary, where the key is a word in that document and the value is a number of how
# many times that word appears in that document.
def build_doc_word_index(data):
    d = {}
    for document, lines in data.items():
        inner_dict = {}

        for line in lines:
            words_in_line = line.split(' ')

            for word in words_in_line:
                if word in inner_dict:
                    inner_dict[word] += 1
                else:
                    inner_dict[word] = 1

            d[document] = inner_dict

    return d

# Build dictionary where the key is a word in the entire corpus and the value
# is the number of times that word appears in the entire corpus.
def build_global_count_index(data):
    d = {}

    return d


# Build a dictionary where the key is the name of the document, and the value is another dictionary,
# where the key is a word in that document and the value is a number of how many times that word appears
# in that document divided by the total number of words in that document.
def build_word_count_index(data):
    d = {}

    return d

# Build a dictionary where the key is the name of the document, and the value is another dictionary,
# where the key is a word in that document and the value is a number of how many times that word appears
# in that document divided by the number of unique words in that document appears.
def build_weighted_word_count_index(data):
    d = {}

    return d

# Build dictionary where the key is a word and the value is a list of all documents where that word appears.
def build_doc_inverted_index(data):
    d = {}

    return d

# Build dictionary where the key is the document name and the value is a list of all unique words in that document
def build_doc_dictionary(data):
    d = {}

    return d


# Build a dictionary where the key is each unique word in the corpus and the value is computed as
# Log (total number of documents in corpus / number of documents containing that word)
# use the log function in the math package
def build_adjusted_index(data):
    d = {}

    return d
