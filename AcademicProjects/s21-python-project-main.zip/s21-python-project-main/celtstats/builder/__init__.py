# this file is loaded into memory when an application imports this package with the following command
# import celtstats.builder

print('loading celtstats.builder module __init__.py')
from .builder import *
