# this file is loaded into memory when an application imports this package with the following command
# import celtstats.viz

print('loading celtstats.viz module __init__.py')
from .plots import *
