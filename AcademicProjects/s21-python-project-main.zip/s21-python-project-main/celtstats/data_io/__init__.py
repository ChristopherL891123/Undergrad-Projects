# this file is loaded into memory when an application imports this package with the following command
# import celtstats.data_io

print('loading celtstats.data_io module __init__.py')
from .data_input import *
from .data_output import *
