# this file is loaded into memory when an application imports this package with the following command
# import celtstats.stats

print('loading celtstats.stats module __init__.py')
from .stats import *
