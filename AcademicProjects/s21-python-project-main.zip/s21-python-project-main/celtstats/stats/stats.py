# given a document name, returns the number of times word appears in that
# document.
def freq_words_doc(data, document, word):
    total = 0

    return total

# given a document name, returns the ranking of that word, based on the
# number of times it appears on that document (you have to sort by count and
# return the highest number)
def rank_words_doc(data, document, word):
    ranking = 0

    return ranking

#  given a document name, return a list of words in that document that begins with that letter.
def word_begin_letter_doc(data, document, letter):
    words_list = []

    return words_list


# given a document name, return the list of words in that document that ends
# with that letter.
def word_end_letter_doc(data, document, letter):
    words_list = []

    return words_list


# given a document name, return a list with all words in that document of a
# given size in characters.
def word_size_doc(data, document, size):
    words_list = []

    return words_list


# given a word, return how many documents contain that word
def freq_docs_count(data, word):
    total = 0

    return total

# given a word, return a list of the documents where that word appear
def freq_docs(data, word):
    document_list = []

    return document_list


# given a count, return a list of documents that have that number of words,
# because the result can be long, return only k documents (where k is an integer)
def freq_docs_words(data, count, k):
    document_list = []

    return document_list

# given a document name, return the result of the number of times that word appear
# in that document divided by the number of unique words in that document.
def freq_words_size_doc(data, document, word):
    total = 0.0

    return total

# given a document and a word, return the following computation: factor + (
# factor * number of times that word appears in the document /
# number of times of the most common word in that document).
def augmented_count_word(data, document, word, factor=0.5):
    computation = 0.0

    return computation



