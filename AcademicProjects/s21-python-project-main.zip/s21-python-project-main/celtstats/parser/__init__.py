# this file is loaded into memory when an application imports this package with the following command
# import celtstats.parser

print('loading celtstats.parser module __init__.py')
from .parse_input_text import *
